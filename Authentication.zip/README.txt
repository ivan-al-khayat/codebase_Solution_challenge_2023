You can try this authentication method at:
https://firebasics-5e0b4.web.app/


Cheers!