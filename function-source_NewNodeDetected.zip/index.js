const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp(functions.config().firebase);
const database = admin.database();
// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });
/**
  * @param {String} zoneId zone to wich i'm sending notification.
  * @param {String} newStatus notifying newstatus to other users.
  * @param {String} alertId needed to inform users that alertID changed status
  */
function notifyUsersOfZone(zoneId, newStatus, alertId) {
  console.log(zoneId, newStatus, alertId);

  const ref=admin.database().ref("/zones/"+zoneId+"/notif_ids");
  ref.on("value", (snapshot) => {
    const mapOfNotifIds = snapshot.val();
    const listOfNotifIds= Object.keys(mapOfNotifIds);
    console.log("mappeeee lista->", listOfNotifIds);

    // --notifying all the people belonging to the specific zone

    // const options =  notification_options
    listOfNotifIds.forEach((deviceId)=> {
      console.log("deviceid->", deviceId);

      const payload = {
        token: deviceId,
        data: {
          score: "850",
          time: "2:45"},
        notification: {
          title: "New fire alert ID: "+ alertId,
          body: "Possible early fire detected! 🔥"},
      };

      admin.messaging().send(payload).then((response)=>{
        console.log("successfully sent message");
      }).catch((error)=>{
        console.log("there was an error sending message");
      });
    });
  });
}
exports.newNodeDetected = functions.database.
    ref("/zones/{zoneId}/ndvi")
    .onUpdate( (snapshot, context)=> {
      console.log("passo");
      const percentageDiff = 20;
      const currentzone= context.params.zoneId;
      const oldNdvi = snapshot.before.val();
      const newNdvi = snapshot.after.val();
      console.log("currentZone->"+currentzone);
      if (Math.abs(newNdvi-oldNdvi) >= (oldNdvi/100*percentageDiff)) {
        const now = new Date();
        const newAlertId = "al_"+now.getTime();
        const ref = database.ref("/alerts/"+newAlertId);
        const currentStatus= "to_solve";
        const newAlertObj= {
          date: now.toLocaleDateString(),
          status: currentStatus,
          zoneid: currentzone,
        };
        ref.set(newAlertObj);
        notifyUsersOfZone(currentzone, currentStatus, newAlertId);
      }
      return;
    });
