const functions = require("firebase-functions");
const admin = require("firebase-admin");
// const fcm = require("fcm-notification");

admin.initializeApp(functions.config().firebase);
// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started
//

/**
  * @param {String} zoneId zone to wich i'm sending notification.
  * @param {String} newStatus notifying newstatus to other users.
  * @param {String} alertId needed to inform users that alertID changed status
  */
function notifyUsersOfZone(zoneId, newStatus, alertId) {
  console.log(zoneId, newStatus, alertId);

  const ref=admin.database().ref("/zones/"+zoneId+"/notif_ids");
  ref.on("value", (snapshot) => {
    const mapOfNotifIds = snapshot.val();
    const listOfNotifIds= Object.keys(mapOfNotifIds);
    console.log("list of notf. Ids->", listOfNotifIds);

    // --notifying all the people belonging to the specific zone

    // const options =  notification_options
    listOfNotifIds.forEach((deviceId)=> {
      console.log("deviceid->", deviceId);

      const payload = {
        token: deviceId,
        data: {
          score: "850",
          time: "2:45"},
        notification: {
          title: "status update for "+ alertId,
          body: "new status is "+ newStatus},
      };

      admin.messaging().send(payload).then((response)=>{
        console.log("successfully sent message");
      }).catch((error)=>{
        console.log("there was an error sending message", error);
      });
    });
  });
}

exports.manageAlert = functions.https.onRequest((request, response) => {
  functions.logger.info("Hello logs!", {structuredData: true});

  // const ref = admin.database().ref("alerts");
  const alertId = request.query.alertId;
  const newStatus= request.query.newStatus;
  const zoneId= request.query.zoneId;
  if ( alertId === undefined || newStatus===undefined ||
        zoneId === undefined ||
    (newStatus!="to_solve" && newStatus!="solving" && newStatus!="solved")) {
    response.status(400).send("you sent me bad data!!");
    return;
  }
  const ref=admin.database().ref("/alerts/"+alertId);
  console.log("log statico");
  ref.update({status: newStatus});
  console.log("ottengo->", ref);
  notifyUsersOfZone(zoneId, newStatus, alertId);
  // ref.set("newstatus");
  response.send("Hello from Firebase, changes applied!");
});
