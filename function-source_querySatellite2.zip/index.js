/* eslint-disable max-len */
/* eslint-disable quotes */
/* eslint-disable camelcase */
/* eslint-disable new-cap */
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp(functions.config().firebase);

exports.querySatellite2 =functions.https.onRequest(async (request, response)=> {
  const ee = await require("@google/earthengine");
  const serviceAccount = await require("./configurazioni/fire-watch-380812"+
"-firebase-adminsdk-mq0nc-1e65b31fcf.json");
  functions.logger.info("Hello logs!", {structuredData: true});
  const a = await ee.data.authenticateViaPrivateKey(serviceAccount, () => {
    console.log("Authentication successful.");
    ee.initialize(
        null, null,
        async () => {
          console.log("Earth Engine client library initialized.");
          // do whatever you need
          // app.listen(port);
          // console.log(`Listening on port ${port}`);
          const ndvisMap ={};
          functions.logger.info("entered in initial!", {structuredData: true});
          // eslint-disable-next-line new-cap
          const italy = ee.Geometry.Rectangle([8.3385, 38.7369,
            9.8369, 40.3707]); // test region
            // Rectangle for the area near Windhoek
          const namibia = ee.Geometry.Rectangle([
            16.5, // west
            -23.0, // south
            17.5, // east
            -22.0]);
            // Rectangle for the area near Manaus
          const brazil = ee.Geometry.Rectangle([
            -61.0, // west
            -3.5, // south
            -59.5, // east
            -1.5]);
          const regions= [{"geom": italy,
            "name": "italy"}, {"geom": brazil,
            "name": "brazil"}, {"geom": namibia,
            "name": "namibia"}];
          const red_band = "B4";// needed for NDVI calc
          const nir_band = "B8";// needed for NDVI calc
          const ndvi_objs = [];
          for (let i=0; i < regions.length; i++) {
            const twoWeeksAgo = new Date(new Date().getTime() -
           (14 * 24 * 60 * 60 * 1000)); // subtract 14 days in milliseconds
            const roi = regions[i].geom; // todo CHANGE TO BE DYNAMIC
            // Load the Sentinel-2 images for the ROI
            const sentinel2 = ee.ImageCollection("COPERNICUS/S2_SR")
                .filterBounds(roi)
                .filterDate(twoWeeksAgo, new Date());
            sentinel2.reduceColumns(
                ee.Reducer.minMax(), ["system:time_start"]);
            const calculateNDVI = function(image) {
              return image.normalizedDifference([nir_band, red_band]).
                  rename("ndvi");
            };
            console.log("calculatedNDVI-Pass");
            const sentinel2_rednir = sentinel2.select([red_band, nir_band]);
            const ndvi = sentinel2_rednir.map(calculateNDVI);
            const sorted_ndvi = ndvi.sort("system:index", false);
            const image = sorted_ndvi.mosaic();// last available image is already ontop. see:https://developers.google.com/earth-engine/guides/ic_composite_mosaic second block
            image.bandNames().map((name) =>{
              return image.select([name]).
                  set("system:time_start", ee.Date.parse("YYYY-MM-dd", name));
            });
            const clippedImage = image.clip(roi);
            const latest_ndvi = clippedImage;
            console.log("debug-let's start");
            const ndvi_obj = latest_ndvi.select("ndvi").
                reduceRegion({
                  reducer: ee.Reducer.first(),
                  geometry: roi,
                  scale: 300});// .get('ndvi');
            console.log("debug completing->"+ ndvi_obj);
            // ndvi_obj.get("ndvi");// .getInfo();
            console.log("debug ended");
            // eslint-disable-next-line max-len
            console.log("debug after->", ndvi_obj.get({key: 'ndvi', defaultValue: undefined}));
            // let's try evaluating serverside obj
            ndvi_objs.push({payload: ndvi_obj, country: regions[i].name});
            // end evaluation
            console.log("debug NDVI value for latest image:", ndvi_obj.get('ndvi'));
            console.log(ndvi_obj.ndvi);
            console.log(regions[i].name);
            // ndvisMap[regions[i].name] = ndvi_obj.ndvi; doesnt work on cloud f
          }
          await ndvi_objs.forEach((ndvi_obj_complex)=> ndvi_obj_complex.
              payload.evaluate(async (dictClient)=> {
                // console.log('Client-side bracket notation to access "ndvi" value',
                //     dictClient['ndvi']);
                console.log('Client-side ops to print all key-value pairs');
                await Object.keys(dictClient).forEach((key)=> {
                  if (key == "ndvi") {
                    console.log("gonna update ndvi on db "+ ndvi_obj_complex.country);
                    const country = ndvi_obj_complex.country;
                    const ndvi = dictClient[key];
                    const ref = admin.database().ref("/zones/"+country);
                    ref.update({ndvi: ndvi});
                  }
                  console.log('    ' + key + ': ' + dictClient[key]);
                });
              }));
          console.log(ndvisMap);
          console.log("EndEEcode");
          // update our rtdb
          // for (const [zoneId, valueOfNdvi] of Object.entries(ndvisMap)) {
          //   const ref = admin.database().ref("/zones/"+zoneId);
          //   ref.update({ndvi: valueOfNdvi});
          // }
        },
        (err) => {
          console.log(err);
          console.log(
              "Please make sure you have created+"+
              " a service account and have been approved.");
        });
  },
  (err) => {
    console.log(err);
  });
  console.log(a);
  response.send("the operation will finish in a few minutes!");
});
