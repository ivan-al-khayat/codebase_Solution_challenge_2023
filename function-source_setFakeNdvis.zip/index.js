const functions = require("firebase-functions");
const admin = require("firebase-admin");
// const fcm = require("fcm-notification");

admin.initializeApp(functions.config().firebase);

// Create and deploy your first functions
// https://firebase.google.com/docs/functions/get-started
exports.setFakeNdvis = functions.https.onRequest( (request, response) => {
  functions.logger.info("Hello logs!", {structuredData: true});
  const randNDvis= {};
  const zones= ["italy", "brazil", "namibia"];
  zones.forEach( (zoneid) =>{
    const ref = admin.database().ref("/zones/"+zoneid);
    const newNdvi= (Math.random()*Math.random()*10) +10;
    randNDvis[zoneid]= newNdvi;
    ref.update({ndvi: newNdvi});
    console.log("pass");
  });
  console.log(JSON.stringify(randNDvis));
  response.send("changed new Ndvis to " + JSON.stringify(randNDvis) +
  ".   Notice that these new random values" +
   " could range from 0 to 20 even if NDVI is from -1 to +1, but it's" +
   " just to have a wider range of values.");
});
