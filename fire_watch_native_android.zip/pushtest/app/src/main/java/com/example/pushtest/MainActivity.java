package com.example.pushtest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    static String token="";
    boolean alredyInitializedApp= false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //FirebaseApp.getInstance().getOptions().
        setContentView(R.layout.activity_main);


        androidx.appcompat.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayOptions(actionBar.getDisplayOptions()
                        | androidx.appcompat.app.ActionBar.DISPLAY_SHOW_CUSTOM);
          ImageView imageView = new ImageView(actionBar.getThemedContext());
           imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
           imageView.setImageResource(R.drawable.app_icon);
           imageView.setPadding(10,10,10,10);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                       Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 60, getResources().getDisplayMetrics())),
                        Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 60, getResources().getDisplayMetrics()))
, Gravity.START
                | Gravity.CENTER_VERTICAL);
        layoutParams.rightMargin = 40;
        imageView.setLayoutParams(layoutParams);
        actionBar.setCustomView(imageView);





        SharedPreferences sp = this.getSharedPreferences("userPrefs",Context.MODE_PRIVATE);
        alredyInitializedApp= !Objects.equals(sp.getString("zone", "null"), "null")
        ;

       // if (savedInstanceState == null) {
            if(!alredyInitializedApp ) {
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .add(R.id.fragment_container_view, UserRoleFragment.newInstance(null,null), null)
                        .commit();
            }else{
                //load homeFragment
                getSupportFragmentManager().beginTransaction()
                        .setReorderingAllowed(true)
                        .add(R.id.fragment_container_view, HomeFragment.newInstance(null,null), null)
                        .commit();
            }
       // }



        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w("tokenazzo", "Fetching FCM registration token failed", task.getException());
                            return;
                        }

                        // Get new FCM registration token
                         token = task.getResult();

                        // Log and toast
                       // String msg = getString("tokenazzo", token);
                        Log.d("tokenazzo", token);
                    }
                });

    }

    public void replaceFragments(Class fragmentClass, String tagIfNotReplace) {
        Fragment fragment = null;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Insert the fragment by replacing any existing fragment
        FragmentManager fragmentManager = getSupportFragmentManager();

           FragmentTransaction ft= fragmentManager.beginTransaction();
           ft.setReorderingAllowed(true);
           ft.replace(R.id.fragment_container_view,fragment,tagIfNotReplace);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.addToBackStack(null);
           ft.commit();


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                if(
                        !MainActivity.this.getSharedPreferences("app_prefs",Context.MODE_PRIVATE)
                .getBoolean("alreadyInitializedApp",false)) { //no initialization done
                    //todo remove
                    startActivity(new Intent(this, SettingsActivity.class));



                }
                else{
                    startActivity(new Intent(this, SettingsActivity.class));
                }

                return true;



            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){
            this.recreate();
        }
    }
}