package com.example.pushtest;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link UserRoleFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class UserRoleFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private View.OnClickListener userRoleClick = v -> {
        SharedPreferences sp = getActivity().getSharedPreferences("userPrefs",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();


        switch(v.getId()){
            case R.id.civilian_button:
                //sharedPrefs save area
                editor.putString("role", "civilian");
                Log.e("userrole","civilian");

                break;
            case R.id.rescuer_button:
                editor.putString("role", "rescuer");
                Log.e("userrole","rescuer");


                break;
        }
        editor.apply();
        // set visibility for userRole


        ((MainActivity)getActivity()).replaceFragments(SelectAreaFragment.class, "select area");
        // FragmentManager mFragmentManager = getActivity().getSupportFragmentManager();
        //FragmentTransaction ft = mFragmentManager.beginTransaction();
        //ft.addToBackStack("home");
        //ft.add(R.id.fragment_container_view, HomeFragment.newInstance(null,null));
        //ft.commit();

    };

    public UserRoleFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static UserRoleFragment newInstance(String param1, String param2) {
        UserRoleFragment fragment = new UserRoleFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_userrole, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.civilian_button).setOnClickListener(userRoleClick);
        view.findViewById(R.id.rescuer_button).setOnClickListener(userRoleClick);

    }
}