package com.example.pushtest
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.example.pushtest.AppConstants
class CustomFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.e("firebase", "received notification")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mNotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val importance = NotificationManager.IMPORTANCE_HIGH
            val mChannel = NotificationChannel(
                AppConstants.FCMConstants.CHANNEL_ID,
                AppConstants.FCMConstants.CHANNEL_NAME,
                importance
            )
            mChannel.description = AppConstants.FCMConstants.CHANNEL_DESC
            mNotificationManager.createNotificationChannel(mChannel)
        }

        if(remoteMessage.data.isNotEmpty()) {
            remoteMessage.data.let {

                var title = it["title"]
                var body = it["message"]
                println("From data object, notification title: $title and body: $body")
                sendNotification(title.toString(), body.toString())
            }
        }

        if (remoteMessage.notification != null){
            var title = remoteMessage.notification?.title
            var body = remoteMessage.notification?.body
            println("From notification object, notification title: $title and body: $body")
            if(!title.isNullOrEmpty() && !body.isNullOrEmpty()){
                sendNotification(title.toString(), body.toString())
            }
        }


    }


    private fun sendNotification(title: String, messageBody: String) {
        var intent: Intent? = null
        //intent = Intent(this, HomeActivity::class.java)
        intent = Intent(this, Application::class.java)

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, 0 /* Request code */, intent,
            PendingIntent.FLAG_ONE_SHOT
        )
        var defaultSoundUri: Uri? = null
        defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel =
                NotificationChannel(
                    AppConstants.FCMConstants.CHANNEL_ID,
                    AppConstants.FCMConstants.CHANNEL_NAME,
                    importance
                )
            channel.description = AppConstants.FCMConstants.CHANNEL_DESC
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            val notificationManager = this.getSystemService(
                NotificationManager::class.java
            )
            notificationManager.createNotificationChannel(channel)
        }
        val notificationBuilder: NotificationCompat.Builder =
            NotificationCompat.Builder(this, AppConstants.FCMConstants.CHANNEL_ID)
                .setStyle(NotificationCompat.BigTextStyle().bigText(messageBody))
                .setContentTitle(title)
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setPriority(NotificationManager.IMPORTANCE_MAX)
                .setChannelId(AppConstants.FCMConstants.CHANNEL_ID)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            notificationBuilder.setSmallIcon(R.drawable.common_google_signin_btn_icon_dark)
            notificationBuilder.color = ContextCompat.getColor(this, R.color.cardview_shadow_end_color)
        } else {
            notificationBuilder.setSmallIcon(R.mipmap.ic_launcher)
        }
        val notificationManager =
            this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build())
    }


    override fun onNewToken(p0: String) {
       // Toast.makeText(applicationContext,"got new good token", Toast.LENGTH_SHORT).show()
        Log.e("NotificationFCM-tokenazzo-", "Token: " + p0)
    }

}