package com.example.pushtest;

 public class AppConstants {
    public static class    FCMConstants {

        public static String CHANNEL_NAME = "channelName";

        public  static String CHANNEL_ID = "channelId";
        public  static String CHANNEL_DESC = "description";
    }
    public static String alertSolved = "solved";
     public static String alertSolving = "solving";
     public static String alertToSolve = "to_solve";

     public enum Alerts{
          solved,
        solving,
        to_solve
    }


}
