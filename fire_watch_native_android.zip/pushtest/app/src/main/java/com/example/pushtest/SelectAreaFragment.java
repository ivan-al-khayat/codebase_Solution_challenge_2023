package com.example.pushtest;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.Objects;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SelectAreaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SelectAreaFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    Button b;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private View.OnClickListener areaListener = v -> {
        SharedPreferences sp = getActivity().getSharedPreferences("userPrefs",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        String myzone="";

        switch(v.getId()){
            case R.id.italy:
                //sharedPrefs save area
                myzone="italy";
                editor.putString("zone", myzone);

                break;
            case R.id.brazil:
                myzone="brazil";
                editor.putString("zone", myzone);
                break;
            case R.id.namibia:
                myzone= "namibia";
                editor.putString("zone", myzone);

                break;
        }
        editor.apply();
        // set visibility for userRole

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://fire-watch-380812-default-rtdb.europe-west1.firebasedatabase.app");

        DatabaseReference myRef = database.getReference("zones/"+myzone+"/"+"notif_ids/"+MainActivity.token);
        myRef.setValue(true);

        ((MainActivity)getActivity()).replaceFragments(HomeFragment.class, "whoIAm");
       // FragmentManager mFragmentManager = getActivity().getSupportFragmentManager();
        //FragmentTransaction ft = mFragmentManager.beginTransaction();
        //ft.addToBackStack("home");
        //ft.add(R.id.fragment_container_view, HomeFragment.newInstance(null,null));
        //ft.commit();

    };

    public SelectAreaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment BlankFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SelectAreaFragment newInstance(String param1, String param2) {
        SelectAreaFragment fragment = new SelectAreaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_select_area, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        b=view.findViewById(R.id.button);

        view.findViewById(R.id.italy).setOnClickListener(areaListener);
        view.findViewById(R.id.namibia).setOnClickListener(areaListener);
        view.findViewById(R.id.brazil).setOnClickListener(areaListener);
        SharedPreferences sp = getActivity().getSharedPreferences("userPrefs",Context.MODE_PRIVATE);
        String role=sp.getString("role","civilian");
        boolean isCivilian=Objects.equals(role, "civilian");
        if(isCivilian){
            view.setBackgroundColor(getActivity().getColor(R.color.app_green));
        }else{
            view.setBackgroundColor(getActivity().getColor(R.color.app_orange));
        }
        getDynamicBgColor(view.findViewById(R.id.italy), isCivilian);
        getDynamicBgColor(view.findViewById(R.id.brazil), isCivilian);
        getDynamicBgColor(view.findViewById(R.id.namibia), isCivilian);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // FirebaseApp.getInstance().getOptions().;
                new Thread(new Runnable() {

                    public  final MediaType JSON
                            = MediaType.get("application/text; charset=utf-8");
                    OkHttpClient client = new OkHttpClient();

                    String post(String url, String regtoken) throws IOException {



                        RequestBody requestBody = new MultipartBody.Builder()
                                .setType(MultipartBody.FORM)
                                .addFormDataPart("registrationToken", regtoken)
                                .build();

                        Request request = new Request.Builder()
                                .url(url)
                                .post(requestBody)
                                .build();
                        try (Response response = client.newCall(request).execute()) {
                            return response.body().string();
                        }
                    }
                    @Override
                    public void run() {
                        try {

                            Log.e("das","registrationToken->"+MainActivity.token);

                            //post("http://10.0.2.2:3000/?registrationToken="+MainActivity.token, MainActivity.token);//localhost from AVD
                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }
                }).start();
            }
        });
    }

    private void getDynamicBgColor(Button v, boolean isCivilian){
        v.setTextColor(
                isCivilian ? getActivity().getColor(R.color.app_green)
                        : getActivity().getColor(R.color.app_orange)
        );
    }
}