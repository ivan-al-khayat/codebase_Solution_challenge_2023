package com.example.pushtest;

import android.app.Application;

import com.google.firebase.FirebaseApp;

public class AppTest extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(getApplicationContext());

    }
}
