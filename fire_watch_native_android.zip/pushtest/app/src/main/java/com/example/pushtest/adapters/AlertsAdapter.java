package com.example.pushtest.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pushtest.Alert;
import com.example.pushtest.AppConstants;
import com.example.pushtest.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;

import okhttp3.FormBody;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AlertsAdapter extends RecyclerView.Adapter<AlertsAdapter.ViewHolder> {

    private ArrayList<Alert> mAlerts=null;
    public AlertsAdapter(ArrayList<Alert> alerts) {
        mAlerts = alerts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        // Inflate the custom layout
        View contactView = inflater.inflate(R.layout.alerts_row, parent, false);

        // Return a new holder instance
        ViewHolder viewHolder = new ViewHolder(contactView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Alert alert = mAlerts.get(position);

        // Set item views based on your views and data model
        TextView dateTv = holder.alertDate;
        dateTv.setText(alert.getAlertDate());
        Button manageButton = holder.manageButton;

        manageButton.setOnClickListener(v -> {
            if (Objects.equals(getNewStatus(alert),"")){
                return;
            }
            new AlertDialog.Builder(v.getContext())
                    .setTitle("do you want to update the status to " + getNewStatus(alert)+ " ?")
                    .setPositiveButton("ok", (dialog, which) -> {
                        //todo call cloud functions & refreshList on response
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    //1.create client Object
                                    OkHttpClient client = new OkHttpClient();
                                    //2.Define request being sent to server
                                    String zoneId= v.getContext().getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
                                            .getString("zone",null);
                                    RequestBody postData=new FormBody.Builder()
                                            .add("alertId",alert.getAlertId())
                                            .add("status", getNewStatus(alert))
                                            .add("zone",
                                                    zoneId
                                                    )
                                            .build();

                                    Request request=new Request.Builder()
                                            .url("https://us-central1-fire-watch-380812.cloudfunctions.net/manageAlert?alertId="
                                            +alert.getAlertId()+"&newStatus="+ getNewStatus(alert)+"&zoneId="+ zoneId)
                                            .post(postData)
                                            .build();

                                    //3.Transport the request and wait for response to process next

                                    Response response = client.newCall(request).execute();
                                    String result = response.body().string();
                                } catch (Exception e) {
                                    Log.d("error_connection","couldn't connect to the API");
                                }
                            }
                        }).start();
                    }).setCancelable(true)
                    .setNegativeButton("cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        });
        if(Objects.equals(manageButton.getContext().getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
                        .getString("role", "civilian")
                , "civilian")){
            manageButton.setVisibility(View.INVISIBLE);
            manageButton.setEnabled(false);
        }
        ImageView statusImageView = holder.alertStatus;
        //todo needs test
        if (Objects.equals(alert.getAlertStatus(), AppConstants.alertSolved) ){
            statusImageView.setImageDrawable(statusImageView.getContext().getDrawable(R.drawable.warning_white));

        }else if (Objects.equals(alert.getAlertStatus(), AppConstants.alertSolving)){
            statusImageView.setImageDrawable(statusImageView.getContext().getDrawable(R.drawable.warning_yellow));
        }else if (Objects.equals(alert.getAlertStatus(), AppConstants.alertToSolve)){
            statusImageView.setImageDrawable(statusImageView.getContext().getDrawable(R.drawable.warning_red));

        }

    }

    @Override
    public int getItemCount() {
        return mAlerts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        // Your holder should contain a member variable
        // for any view that will be set as you render a row
        public TextView alertDate;
        public Button manageButton;
        public ImageView alertStatus;

        // We also create a constructor that accepts the entire item row
        // and does the view lookups to find each subview
        public ViewHolder(View itemView) {
            // Stores the itemView in a public final member variable that can be used
            // to access the context from any ViewHolder instance.
            super(itemView);

            alertDate = (TextView) itemView.findViewById(R.id.alert_date);
            alertStatus = (ImageView) itemView.findViewById(R.id.alert_icon);
            manageButton = (Button) itemView.findViewById(R.id.manageButton);


        }
    }


        public static ArrayList<Alert> createFakeAlerts(int numAlerts) {
            ArrayList<Alert> alerts = new ArrayList<Alert>();
            HashMap<Integer, String> allStatus = new HashMap<>();
            allStatus.put(1, AppConstants.alertSolved);
            allStatus.put(2, AppConstants.alertSolving);
            allStatus.put(3, AppConstants.alertToSolve);

            for (int i = 1; i <= numAlerts; i++) {
                alerts.add(new Alert(allStatus.get(nextInt(1, 4)),
                        "2022 - 07 - 20",
                        "randomAlertId"
                ));
            }

            return alerts;
        }

        public static int nextInt(int min, int max) {
            Random random = new Random();
            return random.nextInt(max - min) + min;
        }
    public String getNewStatus(Alert alert){
        String result="";
        switch (alert.getAlertStatus()) {
            case "to_solve":
                result = "solving";
                break;
            case "solving":
                result = "solved";

        }
        return result;

    }


}
