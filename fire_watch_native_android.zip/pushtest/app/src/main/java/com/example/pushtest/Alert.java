package com.example.pushtest;

public class Alert {
    private String alertStatus= "";
    private String alertDate="";
    private String alertId="";

    public Alert(String alertStatus, String alertDate, String alertId){
        this.alertDate= alertDate;
        this.alertStatus= alertStatus;
        this.alertId= alertId;
    }
    public Alert(){
        // Default constructor required for calls to DataSnapshot.getValue(User.class)

    }

    public String getAlertDate() {
        return alertDate;
    }

    public String getAlertId() {
        return alertId;
    }

    public String getAlertStatus() {
        return alertStatus;
    }
    public void setAlertStatus(String alertStatus){
        this.alertStatus= alertStatus;
    }
    public void  setAlertDate (String alertDate){
        this.alertDate= alertDate;
    }
}
