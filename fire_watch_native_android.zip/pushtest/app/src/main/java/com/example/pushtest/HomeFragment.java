package com.example.pushtest;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private BottomNavigationView nv;
    private AlertsFragment alertsFragment;
    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nv= view.findViewById(R.id.bottomAppBar);
        Context ctx= view.getContext();
        //getActivity().getActionBar().setTitle("faasfasfaaf");
        androidx.appcompat.app.ActionBar actionBar = ((MainActivity)getActivity()).getSupportActionBar();
        SharedPreferences sp = getActivity().getSharedPreferences("userPrefs",Context.MODE_PRIVATE);
        String role=sp.getString("role","civilian");
        actionBar.setTitle("Fire Watch : "+ role);
        int[][] states = new int[][] {
                new int[] { android.R.attr.state_enabled}, // enabled
                new int[] {-android.R.attr.state_enabled}, // disabled
                new int[] {-android.R.attr.state_checked}, // unchecked
                new int[] { android.R.attr.state_pressed}  // pressed
        };

        int defaultColor= Objects.equals(role, "civilian")?
                getActivity().getColor(R.color.app_green)
                :                        getActivity().getColor(R.color.app_orange);
        int[] colors = new int[] {
                defaultColor
                ,
                defaultColor,
                defaultColor,
                defaultColor
        };

        nv.setItemIconTintList(new ColorStateList(states,colors));
        nv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Log.e("clicked navbar button->",item.getTitle().toString());

                switch (item.getItemId()){
                    case R.id.latest_detection_menu:
                        Log.e("dsa","perfetto");
                        replaceFragments(HomePageInfoFragment.class, "detects");
                        break;
                    case R.id.alerts_menu:
                        Log.e("dsa","perfettone");
                        replaceFragments(AlertsFragment.class, "alerts");

                        break;
                }
                return true;
            }
        });
        replaceFragments(HomePageInfoFragment.class,"homeInfo");
    }


    public void replaceFragments(Class fragmentClass, String tag) {
        Fragment fragment = null;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Insert the fragment by replacing any existing fragment
        FragmentManager fragmentManager = getChildFragmentManager();
            if(fragmentManager.findFragmentByTag(tag)!=null){
                fragmentManager.beginTransaction().
                        show(Objects.requireNonNull(fragmentManager.findFragmentByTag(tag))).commit();

            }else {
                fragmentManager.beginTransaction()
                        .add(R.id.home_container, Objects.requireNonNull(fragment), tag).commit();
            }


            Fragment currentFragment= null;
                for (Fragment fr : fragmentManager.getFragments()){
                    if(fr != null && fr.isVisible())
                        currentFragment= fr;
                }

                if (currentFragment!=null && currentFragment.getClass() != fragment.getClass()){
                    fragmentManager.beginTransaction().hide(currentFragment).commit();

                }

    }

}