package com.example.pushtest;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        findViewById(R.id.reinitialize_app).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle("do you really want to reinitialize zone and role?")
                        .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //clean sharedPrefs
                                SharedPreferences sp = getSharedPreferences("userPrefs", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sp.edit();
                                editor.putString("role", null);
                                editor.putString("zone", null);
                                editor.apply();
                                SettingsActivity.this.finish();

                                SettingsActivity.this.startActivityForResult(new Intent(SettingsActivity.this,
                                        MainActivity.class),1);



                            }
                        }).show();
            }
        });
    }
}