package com.example.pushtest;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.pushtest.adapters.AlertsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AlertsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AlertsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AlertsFragment() {
        // Required empty public constructor
    }


    // TODO: Rename and change types and number of parameters
    public static AlertsFragment newInstance(String param1, String param2) {
        AlertsFragment fragment = new AlertsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_alerts, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rvAlerts = (RecyclerView) view.findViewById(R.id.alerts_recycler_view);
        ArrayList<Alert> alertList= AlertsAdapter.createFakeAlerts(15);
        AlertsAdapter adapter = new AlertsAdapter(alertList);
        rvAlerts.setAdapter(adapter);
        // Set layout manager to position the items
        rvAlerts.setLayoutManager(new LinearLayoutManager(view.getContext()));
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://fire-watch-380812-default-rtdb.europe-west1.firebasedatabase.app");

        DatabaseReference myRef = database.getReference("alerts");
        String zone= getActivity()
                .getSharedPreferences("userPrefs", Context.MODE_PRIVATE).getString("zone","no-zone");
        String role = getActivity()
                .getSharedPreferences("userPrefs", Context.MODE_PRIVATE).getString("role","no-role");

        view.setBackgroundColor(Objects.equals(role, "civilian")?
                getActivity().getColor(R.color.app_green)
                :
                getActivity().getColor(R.color.app_orange)
        );

        ((Button)view.findViewById(R.id.refresh_button)).setTextColor(
                Objects.equals(role, "civilian")?
                getActivity().getColor(R.color.app_green)
                :
        getActivity().getColor(R.color.app_orange)
        );

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();

                alertList.clear();
                Log.e("rtdb", map != null ? map.toString() : "map is null");
                for (String key : map.keySet()){
                    String alertId=key;
                    Map<String, Object> alertDetails= (Map<String, Object>) map.get(key);
                    System.out.println(alertDetails);

                    String novelAlertStatus= (String) alertDetails.get("status");
                    String novelAlertDate= (String) alertDetails.get("date");


                    //creating the list of the alerts for your area
                    if(Objects.equals(alertDetails.get("zoneid"),
                            getActivity().getSharedPreferences("userPrefs", Context.MODE_PRIVATE)
                                    .getString("zone",null)
                            )){
                        alertList.add(
                                new Alert(novelAlertStatus,novelAlertDate,key)
                        );
                    }

                }

                adapter.notifyDataSetChanged();
                Log.d("ALertsFragment-", "Value is: " + map.toString());
                //todo- realtime update--this is a persistent listener

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Failed to read value
                Log.w("ALertsFragment-", "Failed to read value.", error.toException());
            }

    });
    myRef.get().addOnCompleteListener(task -> {
        if (!task.isSuccessful()) {
            Log.e("firebase BIANCO", "Error getting data", task.getException());
        }
        else {
            Log.d("firebase NERO", String.valueOf(task.getResult().getValue()));
        }
    });
    }
}
